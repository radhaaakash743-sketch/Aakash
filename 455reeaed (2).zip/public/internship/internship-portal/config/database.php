<?php
// Database connection for Aakash InternHub

$host = "db01.dbhost.dev";
$port = 5051;
$username = "user_455recypw";
$password = getenv("DB_PASSWORD") ?: "p455recypw";
$database = "db_455recypw";

$conn = new mysqli(
    $host,
    $username,
    $password,
    $database,
    $port
);

if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    die("Database connection failed. Please check your configuration.");
}

$conn->set_charset("utf8mb4");
?>
