<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "company") {
    header("Location: ../login.php");
    exit();
}

$stmt = $conn->prepare("SELECT id FROM companies WHERE user_id = ?");
$stmt->bind_param("i", $_SESSION["user_id"]);
$stmt->execute();
$company = $stmt->get_result()->fetch_assoc();

$list = $conn->prepare("SELECT * FROM internships WHERE company_id = ? ORDER BY id DESC");
$list->bind_param("i", $company["id"]);
$list->execute();
$internships = $list->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Internships - Aakash Internhub</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Aakash <span>Internhub</span></a>
        <div class="nav-links"><a href="dashboard.php">Dashboard</a><a href="add_internship.php">Add Internship</a><a href="applicants.php">Applicants</a><a href="../logout.php">Logout</a></div>
    </nav>

    <main class="container">
        <div class="page-heading"><div><div class="badge">POSTED ROLES</div><h1>My Internships</h1><p>Manage your published internship opportunities.</p></div><a class="button primary" href="add_internship.php">+ Add Internship</a></div>

        <div class="cards-grid">
            <?php while ($row = $internships->fetch_assoc()): ?>
                <article class="internship-card">
                    <div class="card-top"><span class="status <?php echo strtolower($row["status"]); ?>"><?php echo htmlspecialchars($row["status"]); ?></span><span><?php echo htmlspecialchars($row["location"]); ?></span></div>
                    <h2><?php echo htmlspecialchars($row["title"]); ?></h2>
                    <p><?php echo htmlspecialchars($row["description"]); ?></p>
                    <div class="tags"><?php echo htmlspecialchars($row["skills"]); ?></div>
                </article>
            <?php endwhile; ?>
        </div>
    </main>
</body>
</html>
