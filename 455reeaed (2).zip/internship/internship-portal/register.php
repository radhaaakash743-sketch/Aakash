<?php
session_start();
require_once "config/database.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $role = $_POST["role"];

    if ($name == "" || $email == "" || $password == "") {
        $message = "Please fill in all required fields.";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            $message = "An account with this email already exists.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $email, $hashed_password, $role);

            if ($stmt->execute()) {
                $user_id = $stmt->insert_id;

                if ($role == "student") {
                    $student = $conn->prepare("INSERT INTO students (user_id) VALUES (?)");
                    $student->bind_param("i", $user_id);
                    $student->execute();
                } else {
                    $company = $conn->prepare("INSERT INTO companies (user_id, company_name) VALUES (?, ?)");
                    $company_name = $name;
                    $company->bind_param("is", $user_id, $company_name);
                    $company->execute();
                }

                header("Location: login.php?registered=1");
                exit();
            }

            $message = "Registration failed. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account - Aakash Internhub</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/validation.js" defer></script>
</head>
<body class="auth-page">
    <div class="auth-box">
        <a class="brand center-brand" href="index.php">Aakash <span>Internhub</span></a>
        <h1>Create your account</h1>
        <p class="auth-subtitle">Join the college internship portal.</p>

        <?php if ($message != ""): ?>
            <div class="alert error"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <form method="POST" onsubmit="return validateRegisterForm()">
            <label>Full Name</label>
            <input type="text" name="name" id="name" placeholder="Enter your name">

            <label>Email</label>
            <input type="email" name="email" id="email" placeholder="Enter your email">

            <label>Password</label>
            <input type="password" name="password" id="password" placeholder="Create a password">

            <label>Account Type</label>
            <select name="role" id="role">
                <option value="student">Student</option>
                <option value="company">Company / Admin</option>
            </select>

            <button class="button primary full" type="submit">Create Account</button>
        </form>

        <p class="auth-bottom">Already have an account? <a href="login.php">Sign in</a></p>
    </div>
</body>
</html>
